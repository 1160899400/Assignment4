import java.sql.*;
import java.util.ArrayList;
public class ProfessorInfo {
	private ArrayList<String> ProInfo;
	public ProfessorInfo(){
		getDatabase();
	}
	public void getDatabase(){
		final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
		//final String URL = "jdbc:mysql://localhost:3306/my_schema?user=root&password=liu19960623&useUnicode=true&characterEncoding=UTF8";
		final String URL = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
		Connection conn = null;
		Statement stmt = null;
		try {
			ProInfo = new ArrayList<String>();
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(URL);
			//System.out.println("Connected database successfully...");
			stmt = conn.createStatement();
			String sql = "SELECT name, educationBackground, researchInterests, email, phone FROM 2014302580200_professor_info";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				ProInfo.add(rs.getString("name")+"  "+rs.getString("educationBackground")+"  "+rs.getString("researchInterests")+"  "+rs.getString("email")+"  "+rs.getString("phone"));
				
			}
			rs.close();
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	public ArrayList<String> getProfessorInfo(){
		return ProInfo;
	}

}
