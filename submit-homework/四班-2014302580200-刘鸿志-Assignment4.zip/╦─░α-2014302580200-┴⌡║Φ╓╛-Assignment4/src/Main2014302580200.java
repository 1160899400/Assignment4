import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JFrame;
public class Main2014302580200 {
	private JFrame Fr;
	private TextField Input;
	private TextArea Output;
	private Button Bt;
	private StartSearch start;
	public String SearchRes; 
	
	public static void main(String[] args){
		Main2014302580200 Run = new Main2014302580200();
		}
	
	public Main2014302580200(){
		Fr = new JFrame("Search the information");
		Fr.setVisible(true);
		Fr.setBounds(20, 20, 600, 400);
		Fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Fr.setLayout(null);
		//����TextField����
		Input = new TextField();
		Input.setBounds(40,10, 300, 30);
		//����TextArea����
		Output = new TextArea();
		Output.setBounds(40,60,450,250);
		//����Button����
		Bt = new Button("start search");
		Bt.setBounds(400, 10, 100, 30);
		Bt.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				//�������ťʱ��ʼ��������
				SearchRes = Input.getText();
				start = new StartSearch(SearchRes);
				Output.setText(start.getOutput());
			}
		});
		
		Fr.add(Input);
		Fr.add(Output);
		Fr.add(Bt);
	}
	public void setInput(String s){
		Input.setText(s);
	}
	public String getInput(){
		return Input.getText();
	}
	public void setOutput(String s){
		Output.setText(Output.getText() + "\n" + s);
	}
	public String getOutput(){
		return Output.getText();
	}
}
