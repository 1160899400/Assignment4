import java.util.ArrayList;


public class CalTF {
	private ArrayList<Integer> TF;
	private ArrayList<String> Words;
	private String content;
	private ArrayList<String>stopList;
	
	public CalTF(String s){
		setContent(s);
		setStopList();
		final char space = ' ';
		content = content.replace('\'', space).replace(',', space).replace('.', space).replace('(', space).replace(')', space).replace('-', space).replace('+', space).replace('@', space).replace('"', space).replace('\n', space);
		Words = new ArrayList<String>();
		TF = new ArrayList<Integer>();
		String word;
		
		
		int begin = 0;
		int end;
		do{
		end = content.indexOf(space,begin) + 1;
		if(end == 0){
			break;
		}
		word = content.substring(begin, end);
		if(!stopList.contains(word)){
			if(Words.contains(word)){
				int Loacation = Words.indexOf(word);
				TF.set(Loacation, TF.get(Loacation)+4);				
			}
			else{
				Words.add(word);
				if(begin <= 20){
					TF.add(10);
					}
				else{
					TF.add(3);
					}
				}
			}
		begin = end;
		}while(begin < content.length()-1);
		begin = content.lastIndexOf(space);
		end = content.length()-1;
		word = content.substring(begin, end);
		if(!stopList.contains(word)){
			if(Words.contains(word)){
				int Loacation = Words.indexOf(word);
				TF.set(Loacation, TF.get(Loacation)+4);				
			}
			else{
				Words.add(word);
				if(begin <= 20){
					TF.add(10);
					}
				else{
					TF.add(3);
					}
				}
			}
	}
	
	public void setContent(String s){
		content = s;
	}
	
	public ArrayList<String> getWords(){
		return Words;
	}
	public ArrayList<Integer> getTF(){
		return TF;
	}
	
	private void setStopList(){
		stopList = new ArrayList<String>();
		stopList.add("of");
		stopList.add("at");
		stopList.add("the");
		stopList.add("by");
		stopList.add("in");
		stopList.add("on");
		stopList.add("this");
		stopList.add("The");
		stopList.add("A");
		stopList.add("B");
		stopList.add(" ");
	}
	
	
}

